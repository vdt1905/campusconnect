import jwt from 'jsonwebtoken';

export const generateTokenAndSetCookies = (res, userId) => {
    // Create JWT token with userId payload and a 7-day expiration time
    const token = jwt.sign({ userId }, process.env.JWT_SECRET, {
        expiresIn: "7d", // Set token expiration time to 7 days
    });

    // Set the token in the cookie with HTTP-only, secure and SameSite settings
    res.cookie("token", token, {
        httpOnly: true, // Make the cookie inaccessible to JavaScript
        secure: process.env.NODE_ENV === 'production', // Only use secure cookies in production (for HTTPS)
        sameSite: 'strict', // Enforces strict cookie policy
        maxAge: 7 * 24 * 60 * 60 * 1000, // Cookie expires in 7 days (same as JWT expiration)
    });

    return token; // Return token (optional, in case you need it elsewhere)
};
