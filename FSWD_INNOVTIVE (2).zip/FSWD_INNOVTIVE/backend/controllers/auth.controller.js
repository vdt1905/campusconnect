import { User } from "../models/user.model.js";
import crypto from "crypto"
import bcrypt from "bcrypt";
import { generateTokenAndSetCookies } from "../utils/generateTokenAndSetCookies.js";
import jwt from 'jsonwebtoken';
import { sendVerificationEmail, sendWelcomeEmail, sendPasswordResetEmail, sendResetSuccessEmail } from "../mailtrap/emails.js";
import bcryptjs from "bcryptjs"
export const signup = async (req, res) => {
    const { username, email, password } = req.body;

    try {
        if (!username || !email || !password) {
            return res.status(400).json({ message: "Please fill in all fields." });
        }

        const userAlreadyExist = await User.findOne({ email });
        if (userAlreadyExist) {
            return res.status(400).json({ success: false, message: "Email already in use." });
        }

        const usernameExist = await User.findOne({ username });
        if (usernameExist) {
            return res.status(400).json({ success: false, message: "Username already in use." });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const verificationToken = Math.floor(100000 + Math.random() * 900000).toString();

        // Create user object first
        const user = new User({
            username,
            email,
            password: hashedPassword,
            verificationToken,
            verificationTokenExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // Token expiration time
        });

        // Log to verify token and expiration time before saving
        console.log("Saving user with verification token:", user.verificationToken);
        console.log("Token expiration time:", user.verificationTokenExpiresAt);

        // Save the user once the user object is fully created
        const savedUser = await user.save();
        console.log("User saved:", savedUser);

        // Generate JWT and set cookies
        generateTokenAndSetCookies(res, savedUser._id);

        // Send verification email
        await sendVerificationEmail(savedUser.email, verificationToken);

        res.status(201).json({
            success: true,
            message: "User created successfully",
            user: {
                ...savedUser.toObject(),
                password: undefined // Remove password from the response
            }
        });

    } catch (error) {
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const signin = async (req, res) => {
    try {
        console.log("Request Body:", req.body); // Debugging step

        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: "Please provide username and password" });
        }

        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ success: false, message: "No user with this username" });
        }

        const isPassValid = await bcrypt.compare(password, user.password);
        if (!isPassValid) {
            return res.status(400).json({ success: false, message: "Invalid password" });
        }

        generateTokenAndSetCookies(res, user._id);

        res.status(200).json({
            success: true,
            message: "Logged in successfully",
            user: { ...user.toObject(), password: undefined },
        });

    } catch (error) {
        console.error("Error during sign-in:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const verifyEmail = async (req, res) => {
    const { code } = req.body;
    const trimmedCode = code?.trim();
    console.log("Code received from frontend:", trimmedCode);

    try {
        // List all tokens from DB for debugging
        const allUsers = await User.find({}, { email: 1, verificationToken: 1 });
        console.log("All verification tokens in DB:");
        allUsers.forEach(u => console.log(`${u.email}: ${u.verificationToken}`));

        // Show forced match check
        const userWithoutExpiryCheck = await User.findOne({});
        if (userWithoutExpiryCheck) {
            console.log("🔍 Manual match test:");
            console.log("Frontend code:", trimmedCode);
            console.log("Stored code:", userWithoutExpiryCheck.verificationToken);
            console.log("Match:", trimmedCode === userWithoutExpiryCheck.verificationToken);
        }

        // Now the actual query
        const user = await User.findOne({
            verificationToken: trimmedCode,
            verificationTokenExpiresAt: { $gt: Date.now() },
        });

        if (!user) {
            console.log("❌ Token found, but token has likely expired or mismatch.");
            return res.status(400).json({ success: false, message: "Invalid or expired verification code" });
        }

        user.isVerified = true;
        user.verificationToken = undefined;
        user.verificationTokenExpiresAt = undefined;
        await user.save();

        await sendWelcomeEmail(user.email, user.name);

        res.status(200).json({
            success: true,
            message: "Email verified successfully",
            user: {
                ...user._doc,
                password: undefined,
            },
        });
    } catch (error) {
        console.log("error in verifyEmail ", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};



export const forgotPassword = async (req, res) => {
	const { email } = req.body;
	try {
		const user = await User.findOne({ email });

		if (!user) {
			return res.status(400).json({ success: false, message: "User not found" });
		}

		// Generate reset token
		const resetToken = crypto.randomBytes(20).toString("hex");

		// Set the expiration time for the reset token (e.g., 1 hour from now)
		const resetTokenExpiresAt = Date.now() + 1 * 60 * 60 * 1000; // 1 hour


		// Save the reset token and its expiration time to the database
		user.resetPasswordToken = resetToken;
		user.resetTokenExpiresAt = resetTokenExpiresAt;

		// Save the user with the reset token and expiration time
		await user.save();

		// Send password reset email to the user with the reset link
		await sendPasswordResetEmail(user.email, `${process.env.CLIENT_URL}/reset-password/${resetToken}`);

		res.status(200).json({ success: true, message: "Password reset link sent to your email" });
	} catch (error) {
		console.log("Error in forgotPassword ", error);
		res.status(400).json({ success: false, message: error.message });
	}
};



export const signout = async (req, res) => {
    res.cookie("jwt", "", { expires: new Date(0), httpOnly: true }); // Force cookie expiration
    res.status(200).json({ success: true, message: "Logged out successfully" });
};

export const resetPassword = async (req, res) => {
    try {
        const { token } = req.params;  // Token from URL path
        const { password } = req.body; // New password from the request body
        
        console.log("Token received from frontend:", token);
        console.log("New password:", password);

        // Check if token and password exist
        if (!token || !password) {
            return res.status(400).json({ success: false, message: "Token or password missing" });
        }
        // Find the user by reset token and ensure it hasn't expired
        const user = await User.findOne({
            resetPasswordToken: token,
            resetTokenExpiresAt: { $gt: Date.now() }, // Check token expiration
        });

        // Log the user found
        console.log("User found:", user);

        // If no user or the token is expired, send error response
        if (!user) {
            console.log("Invalid or expired reset token");
            return res.status(400).json({ success: false, message: "Invalid or expired reset token" });
        }

        // Hash the new password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Update the user's password and clear the reset token and expiry time
        user.password = hashedPassword;
        user.resetPasswordToken = undefined; // Clear the reset token
        user.resetTokenExpiresAt = undefined; // Clear the expiry time
        await user.save(); // Save the updated user

        // Send a confirmation email
        await sendResetSuccessEmail(user.email);

        // Send success response
        res.status(200).json({ success: true, message: "Password reset successful" });
    } catch (error) {
        console.log("Error in resetPassword:", error.message);
        res.status(500).json({ success: false, message: "Server error, please try again later" });
    }
};




export const checkAuth = async (req, res) => {
	try {
		const user = await User.findById(req.userId).select("-password");
		if (!user) {
			return res.status(400).json({ success: false, message: "User not found" });
		}

		res.status(200).json({ success: true, user });
	} catch (error) {
		console.log("Error in checkAuth ", error);
		res.status(400).json({ success: false, message: error.message });
	}
};