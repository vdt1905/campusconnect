import { MailtrapClient }  from "mailtrap" ;

const TOKEN = "356895acf2836f1ef7557445a9929068";

export const mailtrapClient = new MailtrapClient({
  token: TOKEN,
});

export const sender = {
  email: "hello@demomailtrap.co",
  name: "vansh",
};
