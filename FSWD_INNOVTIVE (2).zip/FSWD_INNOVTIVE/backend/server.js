import express from "express"
import {connectDB} from "./DB/connectDB.js"
import dotenv from "dotenv";
import authroutes from "./routes/auth.js";
import cors from "cors";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";

dotenv.config();
const PORT = process.env.PORT
const app= express()
app.use(cors({
    origin: 'http://localhost:5173',
    credentials: true // allow cookies to be sent
  }));
app.use(express.json())
app.use(cookieParser())
app.use(bodyParser.urlencoded({ extended: true }));



app.use("/api/auth",authroutes)

app.listen(PORT,()=>{
    connectDB()
    console.log("server is running on port ",PORT)
})